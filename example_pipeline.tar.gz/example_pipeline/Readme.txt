This archive contains the example pipeline with 1 sample from 1000 Genomes dataset.

You can run it on a Linux system with the command:
./example_pipeline.sh sample_names.txt

Before running, check the paths for plink\bcftools in the scripts merge_dataset_with_reference.sh and example_pipeline.sh. 


