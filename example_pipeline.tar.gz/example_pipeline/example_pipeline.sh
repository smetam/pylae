#!/bin/bash
export BCFTOOLS_PLUGINS=/home/bcftools-1.12/plugins

while read p; do
    echo $p

./merge_dataset_with_reference.sh ${p} example_reference
cp Zombie_groups_3.txt zombie_groups_mp_${p}.txt
sed -i "s/test/$p/g" zombie_groups_mp_${p}.txt
plink --bfile $p'_plus_reference' --alleleACGT  --recode vcf --out $p'_merged' --threads 8
bcftools view ${p}_merged.vcf -c 1 -Ou > ${p}_1.vcf
bcftools +fill-tags ${p}_1.vcf -Ou -o ${p}_2.bcf -- -S zombie_groups_mp_${p}.txt -t AF 
bcftools query ${p}_2.bcf  -H -f "%CHROM %POS %AF_${p} %AF_Mediterranean %AF_NorthernEuropean %AF_SubsaharanAfrican\n" > ${p}.txt
sed -i "s/# //g" ${p}.txt
sed -i "s/  / /g" ${p}.txt
rm zombie_groups_mp_${p}.txt
rm ${p}_2.bcf
rm ${p}_1.vcf

python3 ./pylae/src/bayes_viterbi.py --sample $p --window-len 50 ${p}.txt -o res50_1kg_new_mp -m --admixtures example.csv

done < $1