#!/bin/bash
##sed -i 's/chr//g' *.map

# ${1} = basename of ped/map file
# ${2} = basename of reference ped/map file

# if there are leftovers from previous tries, remove them
# they would be overwritten anyway (and we need to test for their presence)
if [[ -e "${1}_plus_reference.bed" ]]
then
	rm ${1}_plus_reference.*
fi

echo "=================================================================================="
echo "getting snp lists from reference data and from the sample"
cut -f 2 ${1}.map > ${1}.snps

tail  ${1}.snps


cut -f 2 ${2}.map -d' '> ${2}.snps

tail  ${2}.snps

wc ${1}.snps
wc ${2}.snps

##grep -v '1:181955262' ${1}.snps | grep -v '20:42575239' | grep -v '20:42575239' | grep -v '3:947955' | grep -v '5:169133825' > ${1}.snps

##grep -v '1:181955262' ${2}.snps | grep -v '20:42575239' | grep -v '20:42575239' | grep -v '3:947955' | grep -v '5:169133825' > ${2}.snps

wc ${1}.snps
wc ${2}.snps

break;
echo "=================================================================================="
echo "extracting reference alleles from sample file"
plink --memory 14000 --file ${1} --extract ${2}.snps --make-bed --allele1234 --out ${1}_ref_alleles
echo ""
echo "=================================================================================="
echo "extracting sample's snps from reference set"
plink --memory 14000 --file ${2} --extract ${1}.snps --make-bed --allele1234 --out ${2}_alleles_from_${1}

#read -p "Press any key to continue... " -n1 -s
echo ""

rm ${1}.snps
rm ${2}.snps

#if [ $(diff ${1}_ref_alleles.map ${2}_alleles_from_${1}.map | wc -l) != 0 ];then
#	echo "MAP file do not match. Please check manually"
#	exit
#fi

samples=`cat ${1}_ref_alleles.fam | wc -l`
ref_samples=`cat ${2}_alleles_from_${1}.fam | wc -l`

echo "=================================================================================="
echo ""
echo "Samples in this file: " $samples
echo "Originaly SNPs: "
wc -l ${1}.ped
echo ""
echo "SNPs after merging with reference: "
wc -l ${1}_ref_alleles.bim
echo ""
echo "Merged dataset will be called: " ${1}"_plus_reference.bed/bim/fam"
echo "======================================================================================"
echo "creating pop file"
echo "-" > ${1}_plus_reference.pop
for i in `seq 2 $samples`;do
	echo "-" >> ${1}_plus_reference.pop
done
cut -d' ' -f 1 ${2}_alleles_from_${1}.fam >> ${1}_plus_reference.pop

#read -p "Press any key to continue... " -n1 -s
echo ""
#cat ${1}_ref_alleles.ped ${2}_alleles_from_${1}.ped > ${1}_plus_reference.ped
#cp ${1}_ref_alleles.map ${1}_plus_reference.map

echo ""
echo "======================================================================================"
echo "merging sample and reference sets"
echo plink --bfile ${1}_ref_alleles --bmerge ${2}_alleles_from_${1}.bed ${2}_alleles_from_${1}.bim ${2}_alleles_from_${1}.fam --allow-no-sex --indiv-sort 0 --make-bed --out ${1}_plus_reference
plink --bfile ${1}_ref_alleles --bmerge ${2}_alleles_from_${1}.bed ${2}_alleles_from_${1}.bim ${2}_alleles_from_${1}.fam --allow-no-sex --indiv-sort 0 --make-bed --out ${1}_plus_reference

if [[ -e "${1}_plus_reference.bed" ]]
then
	echo "There were no problems merging :-)"
	rm ${1}_ref_alleles.*
	rm ${2}_alleles_from_${1}.*
else
	if ! [[ -e ${1}_plus_reference-merge.missnp ]]
	then
		echo "======================================================================================"
		echo "Last plink run didn't merge the files but didn't create *.missnp file either. Please investigate!"
		exit
	fi
	echo "======================================================================================"
	echo "Excluding problematic SNPs from file with samples"
	echo ""	
	echo plink --bfile ${1}_ref_alleles --exclude ${1}_plus_reference-merge.missnp --make-bed --out ${1}_ref_alleles_consistent
	plink --bfile ${1}_ref_alleles --exclude ${1}_plus_reference-merge.missnp --make-bed --out ${1}_ref_alleles_consistent
	echo "======================================================================================"
	echo "Excluding problematic SNPs from file with reference set (zombies)"
	echo ""
	echo plink --bfile ${2}_alleles_from_${1}  --exclude ${1}_plus_reference-merge.missnp --make-bed --out ${2}_alleles_from_${1}_consistent
	plink --bfile ${2}_alleles_from_${1}  --exclude ${1}_plus_reference-merge.missnp --make-bed --out ${2}_alleles_from_${1}_consistent
	echo "======================================================================================"
	echo "Merging datasets - second try"
	echo ""
	echo "Removed --indiv-sort 0"
	echo plink --bfile ${1}_ref_alleles_consistent --bmerge ${2}_alleles_from_${1}_consistent --allow-no-sex --indiv-sort 0 --make-bed --out ${1}_plus_reference
	plink --bfile ${1}_ref_alleles_consistent --bmerge ${2}_alleles_from_${1}_consistent --allow-no-sex --indiv-sort 0 --make-bed --out ${1}_plus_reference
	if [[ -e "${1}_plus_reference.bed" ]]
	then
		rm ${1}_ref_alleles_consistent.*
		rm ${2}_alleles_from_${1}_consistent.*
		rm ${1}_ref_alleles.*
		rm ${2}_alleles_from_${1}.*
		echo "Success!"
	else
		echo "Still did not succeed to merge! Please examine what went wrong. Keeping the files"
	fi
fi

echo "Running supervised admixture"
